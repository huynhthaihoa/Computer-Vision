% PHD_TOOL
%
% Files
%   check_PhD_install - This scripts checks the installation of the PhD face recognition toolbox. 
%   install_PhD       - This is the install script for the PhD face recognition toolbox. 
