% PLOTS
%
% Files
%   plot_CMC_PhD - The function plots the so-called CMC curve based on the provided input data
%   plot_EPC_PhD - The function plots the so-called EPC curve based on the provided input data
%   plot_ROC_PhD - The function plots the so-called ROC curve based on the provided input data
