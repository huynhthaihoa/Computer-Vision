% CLASSIFICATION
%
% Files
%   nn_classification_PhD - Performs matching score calculation based on the nearest neighbor classifier
%   return_distance_PhD   - This is an auxilary function that returns the specified distance
