% POSTPROCESSORS
%
% Files
%   histtruncate         - The function truncates the ends of an image histogram.
%   robust_postprocessor - The function performs postprocessing of the photometrically normalized image X
