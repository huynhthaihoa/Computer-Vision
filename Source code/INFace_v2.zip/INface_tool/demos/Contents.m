% DEMOS
%
% Files
%   combin_demo      - A demo script showing the application of the photometric normalization techniques in conjucntion with rank normalization on a sample image.
%   histograms_demo  - A demo script showing the application of the histogram manipulation techniques on a sample image.
%   photometric_demo - A demo script showing the application of the photometric normalization techniques on a sample image.
%   luminance_demo       - A demo script showing the procedure of computing the luminance functions.
%   make_new_method_demo - A demo script how to combine different functions from the toolbox into a novel technique
